
class CallCounter(object):
    '''
    Decorator for counting number of function calls
    
    >>> @CallCounter
    ... def f(x, y, z=1):
    ...     return x+y*z
    ... 
    >>> f(2, 4, 6)
    26
    >>> f(3, 5, 7)
    38
    >>> f(8, 2)
    10
    >>> CallCounter.counter
    3
    '''
